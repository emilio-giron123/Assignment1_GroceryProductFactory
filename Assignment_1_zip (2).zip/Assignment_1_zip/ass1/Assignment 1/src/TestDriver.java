import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class TestDriver {
    public static void main(String[] args) throws IOException {
        GroceryProductFactory productFactory = FactoryProducer.getFactory(false);

        Product product1 = ItemsFactory.getProduct("BANANA");
        product1.setQuantity();

        Product product2 = ItemsFactory.getProduct("APPLE");
        product2.setQuantity();
    }
}
