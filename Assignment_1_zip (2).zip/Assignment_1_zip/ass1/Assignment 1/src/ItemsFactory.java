public class ItemsFactory extends GroceryProductFactory{
    public static Product getProduct(String productType){
        if(productType.equalsIgnoreCase("BANANA")){
            return new Banana();
        } else if (productType.equalsIgnoreCase("APPLE")) {
            return new Apple();
        }
        return null;
    }
}
