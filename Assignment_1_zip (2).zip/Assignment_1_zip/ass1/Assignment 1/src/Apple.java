import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
public class Apple implements Product{
    @Override
    public void setQuantity() throws IOException {
        System.out.println("Apple Pricing: $");
        Scanner reader = new Scanner(System.in);
        String apple;
        apple = reader.next();

        System.out.println("The price of each Apple is: $" +apple);

        Files.write(Paths.get("DataFile1.txt"), Arrays.asList(apple), StandardCharsets.UTF_8);
    }
}
