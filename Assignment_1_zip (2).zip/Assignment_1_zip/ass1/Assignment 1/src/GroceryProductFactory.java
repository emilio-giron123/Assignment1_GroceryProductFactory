public abstract class GroceryProductFactory {
    static Product getProduct(String productType) {
        return null;
    }
}
