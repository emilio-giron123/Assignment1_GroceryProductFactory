public class FactoryProducer {
    public static GroceryProductFactory getFactory(boolean banana) {
        return new ItemsFactory();
    }
}
