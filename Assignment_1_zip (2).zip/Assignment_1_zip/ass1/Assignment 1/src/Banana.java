import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Scanner;
public class Banana implements Product{
    @Override
    public void setQuantity() throws IOException {
        System.out.println("Banana Pricing: $");
        Scanner reader = new Scanner(System.in);
        String banana;
        banana = reader.next();

        System.out.println("The price of each banana is: $" +banana);

        Files.write(Paths.get("DataFile2.txt"), Arrays.asList(banana), StandardCharsets.UTF_8);
    }
}
